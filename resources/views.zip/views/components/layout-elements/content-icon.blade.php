<div @class(getBaseAndAnimClasses($element['data']))>
    <i @class(['bi',$icon])></i>
</div>