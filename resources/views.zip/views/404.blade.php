<x-fe-layout>

    <x-page-header :headerVideo="null"  :title="'404'" :headerImage="null" :parentTitle="''"/>

    <section class="content-section">
        <div class="container text-center fs-3">
            Aradığınız sayfa bulunamadı...
        </div>
    </section>

    <x-slot name="headerScripts">
        
    </x-slot>

    <x-slot name="footerScripts">
        
    </x-slot>

</x-fe-layout>